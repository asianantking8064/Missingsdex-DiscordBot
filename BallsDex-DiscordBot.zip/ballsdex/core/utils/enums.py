DONATION_POLICY_MAP = {
    1: "Accept all donations",
    2: "Approve donations",
    3: "Deny all donations",
}

PRIVATE_POLICY_MAP = {1: "Public", 2: "Private", 3: "Mutual Servers"}
